<?php
session_start();

 include "layout/header.php";

if(!isset($_SESSION["nombre"])){
    header("Location: ../index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard | BioAsist</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

:root{
    --verde:#39A900;
    --verde-oscuro:#1f6b00;
    --verde-claro:#eaf7e0;
    --negro:#0d1b08;
    --negro-suave:#15290e;
}

*{
    box-sizing:border-box;
}

body{
    background:#f4f6f9;
    font-family:'Segoe UI', Roboto, Arial, sans-serif;
}

/* ===================== SIDEBAR ===================== */

.sidebar{
    background:linear-gradient(180deg, var(--negro) 0%, var(--negro-suave) 100%);
    min-height:100vh;
    padding:24px 18px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.sidebar-brand{
    display:flex;
    align-items:center;
    gap:12px;
    margin-bottom:32px;
}

.sidebar-brand .icon-box{
    width:42px;
    height:42px;
    background:var(--verde);
    border-radius:10px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:20px;
    color:#fff;
    flex-shrink:0;
}

.sidebar-brand h5{
    color:#fff;
    margin:0;
    font-weight:700;
    font-size:16px;
}

.sidebar-brand small{
    color:#b9c9b0;
    font-size:11px;
}

.sidebar-nav a{
    color:#cfd9c8;
    text-decoration:none;
    display:flex;
    align-items:center;
    gap:12px;
    padding:11px 14px;
    border-radius:10px;
    margin-bottom:6px;
    font-size:14px;
    transition:.15s;
}

.sidebar-nav a i{
    width:18px;
    text-align:center;
}

.sidebar-nav a:hover{
    background:rgba(57,169,0,.18);
    color:#fff;
}

.sidebar-nav a.active{
    background:var(--verde);
    color:#fff;
    font-weight:600;
}

.sidebar-bottom{
    margin-top:24px;
}

.sidebar-biometric{
    background:rgba(57,169,0,.15);
    border:1px solid rgba(57,169,0,.4);
    border-radius:12px;
    padding:12px 14px;
    display:flex;
    align-items:center;
    gap:10px;
    margin-bottom:18px;
}

.sidebar-biometric .icon-box{
    width:34px;
    height:34px;
    background:var(--verde);
    border-radius:8px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#fff;
    font-size:15px;
    flex-shrink:0;
}

.sidebar-biometric strong{
    color:#fff;
    font-size:13px;
    display:block;
}

.sidebar-biometric span{
    color:#7ddc5a;
    font-size:11px;
}

.sidebar-biometric span i{
    font-size:8px;
    margin-right:4px;
}

.sidebar-footer{
    color:#7e8c76;
    font-size:11px;
    text-align:left;
    line-height:1.6;
}

/* ===================== TOPBAR ===================== */

.topbar{
    background:#fff;
    padding:18px 28px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    border-bottom:1px solid #eaeaea;
}

.topbar h4{
    margin:0;
    font-size:20px;
    font-weight:600;
    color:#1a1a1a;
}

.topbar h4 .nombre-user{
    color:var(--verde);
}

.topbar p{
    margin:0;
    font-size:13px;
    color:#7a8478;
}

.topbar-right{
    display:flex;
    align-items:center;
    gap:18px;
}

.notif-bell{
    position:relative;
    width:38px;
    height:38px;
    border-radius:10px;
    background:#f4f6f4;
    border:1px solid #e8e8e8;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#444;
    font-size:15px;
}

.notif-bell .badge-count{
    position:absolute;
    top:-5px;
    right:-5px;
    background:var(--verde);
    color:#fff;
    font-size:10px;
    font-weight:700;
    width:18px;
    height:18px;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
}

.user-mini{
    display:flex;
    align-items:center;
    gap:10px;
}

.user-mini .avatar-circle{
    width:36px;
    height:36px;
    border-radius:50%;
    background:#e3e3e3;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#777;
    font-size:16px;
}

.user-mini .info p{
    margin:0;
    font-size:13px;
    font-weight:600;
    color:#1a1a1a;
}

.user-mini .info span{
    font-size:11px;
    color:#8a8a8a;
}

/* ===================== CONTENIDO ===================== */

.content-area{
    padding:26px 28px;
}

.fecha-box{
    text-align:right;
    margin-bottom:14px;
    color:#777;
    font-size:13px;
}

.fecha-box strong{
    display:block;
    color:#1a1a1a;
    font-size:14px;
}

/* ===================== TARJETAS RESUMEN ===================== */

.stat-card{
    background:#fff;
    border-radius:14px;
    padding:18px;
    display:flex;
    align-items:center;
    gap:14px;
    border:1px solid #eef1ee;
}

.stat-card .icon-circle{
    width:50px;
    height:50px;
    border-radius:12px;
    background:var(--verde-claro);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:20px;
    color:var(--verde);
    flex-shrink:0;
}

.stat-card .icon-circle.warning{
    background:#fff6e0;
    color:#e6a400;
}

.stat-card .icon-circle.danger{
    background:#fdeaea;
    color:#e53935;
}

.stat-card .stat-label{
    font-size:13px;
    color:#777;
    margin-bottom:2px;
}

.stat-card h2{
    font-size:26px;
    font-weight:700;
    margin:0 0 2px;
    color:#1a1a1a;
}

.stat-card .stat-sub{
    font-size:12px;
    color:#8a8a8a;
}

.stat-card .stat-sub.positivo{
    color:var(--verde);
}

.stat-card .stat-sub.alerta{
    color:#e6a400;
}

.stat-card .stat-sub.negativo{
    color:#e53935;
}

/* ===================== TARJETAS GENERALES ===================== */

.panel-card{
    background:#fff;
    border-radius:14px;
    border:1px solid #eef1ee;
    padding:18px 20px;
    height:100%;
}

.panel-card .panel-title{
    display:flex;
    align-items:center;
    justify-content:space-between;
    margin-bottom:16px;
}

.panel-card .panel-title h6{
    margin:0;
    font-size:15px;
    font-weight:600;
    color:#1a1a1a;
    display:flex;
    align-items:center;
    gap:8px;
}

.panel-card .panel-title h6 i{
    color:var(--verde);
}

.panel-card select{
    border:1px solid #e3e3e3;
    border-radius:8px;
    font-size:12px;
    padding:5px 10px;
    color:#555;
    background:#fafafa;
}

/* ===================== ACTIVIDAD ===================== */

.actividad-item{
    display:flex;
    align-items:center;
    gap:12px;
    padding:10px 0;
    border-bottom:1px solid #f3f3f3;
}

.actividad-item:last-of-type{
    border-bottom:none;
}

.actividad-item .avatar-circle{
    width:36px;
    height:36px;
    border-radius:50%;
    background:#eef1ee;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#9aa39a;
    font-size:15px;
    flex-shrink:0;
}

.actividad-item .info{
    flex:1;
    min-width:0;
}

.actividad-item .info p{
    margin:0;
    font-size:13px;
    font-weight:600;
    color:#1a1a1a;
}

.actividad-item .info span{
    font-size:12px;
    color:#8a8a8a;
}

.actividad-item .hora{
    font-size:11px;
    color:#9a9a9a;
    white-space:nowrap;
}

.actividad-item .check-ok{
    width:20px;
    height:20px;
    border-radius:50%;
    background:var(--verde);
    color:#fff;
    font-size:11px;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
}

.ver-todas{
    display:flex;
    align-items:center;
    justify-content:space-between;
    margin-top:12px;
    font-size:13px;
    color:#555;
    text-decoration:none;
}

.ver-todas:hover{
    color:var(--verde);
}

/* ===================== ACCESOS RAPIDOS ===================== */

.acceso-btn{
    background:var(--verde-claro);
    border-radius:12px;
    border:none;
    padding:16px 10px;
    text-align:center;
    color:#1f5500;
    text-decoration:none;
    display:block;
    font-size:13px;
    font-weight:500;
    transition:.15s;
}

.acceso-btn i{
    display:block;
    font-size:22px;
    margin-bottom:8px;
    color:var(--verde);
}

.acceso-btn:hover{
    background:var(--verde);
    color:#fff;
}

.acceso-btn:hover i{
    color:#fff;
}

/* ===================== ESTADO DEL SISTEMA ===================== */

.estado-item{
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:9px 0;
    font-size:13px;
    color:#444;
    border-bottom:1px solid #f3f3f3;
}

.estado-item:last-of-type{
    border-bottom:none;
}

.estado-item .label{
    display:flex;
    align-items:center;
    gap:8px;
}

.estado-item .label i{
    color:#9aa39a;
    width:16px;
}

.estado-dot{
    display:inline-block;
    width:7px;
    height:7px;
    border-radius:50%;
    background:var(--verde);
    margin-right:5px;
}

.estado-valor{
    font-size:12px;
    color:#555;
}

.barra-progreso{
    width:90px;
    height:6px;
    background:#eee;
    border-radius:4px;
    overflow:hidden;
    display:inline-block;
    margin-right:8px;
    vertical-align:middle;
}

.barra-progreso-fill{
    height:100%;
    background:var(--verde);
}

.estado-ok-box{
    background:var(--verde);
    border-radius:12px;
    color:#fff;
    text-align:center;
    padding:18px 10px;
    display:flex;
    flex-direction:column;
    align-items:center;
    justify-content:center;
    height:100%;
}

.estado-ok-box i{
    font-size:26px;
    margin-bottom:8px;
}

.estado-ok-box strong{
    font-size:13px;
}

</style>

</head>

<body>

<div class="container-fluid p-0">

<div class="row g-0">

<!-- MENU -->

<div class="col-md-2 sidebar">

    <div>

        <div class="sidebar-brand">
            <div class="icon-box"><i class="fas fa-seedling"></i></div>
            <div>
                <h5>BioAsist SENA</h5>
                <small>Sistema Biométrico de Asistencia</small>
            </div>
        </div>

        <div class="sidebar-nav">

            <a href="dashboard.php" class="active">
                <i class="fas fa-home"></i>
                Inicio
            </a>

            <a href="aprendices.php">
                <i class="fas fa-user-graduate"></i>
                Aprendices
            </a>

            <a href="asistencia.php">
                <i class="fas fa-fingerprint"></i>
                Asistencia
            </a>

            <a href="programas.php">
                <i class="fas fa-book"></i>
                Programas
            </a>

            <a href="reportes.php">
                <i class="fas fa-file-pdf"></i>
                Reportes
            </a>

            <a href="historial.php">
                <i class="fas fa-clock"></i>
                Historial
            </a>

            <a href="dispositivos.php">
                <i class="fas fa-microchip"></i>
                Dispositivos
            </a>

            <a href="configuracion.php">
                <i class="fas fa-cog"></i>
                Configuración
            </a>

        </div>

    </div>

    <div class="sidebar-bottom">

        <div class="sidebar-biometric">
            <div class="icon-box"><i class="fas fa-fingerprint"></i></div>
            <div>
                <strong>Sistema biométrico</strong>
                <span><i class="fas fa-circle"></i>Conectado</span>
            </div>
        </div>

        <div class="sidebar-footer">
            © <?php echo date("Y"); ?> SENA<br>
            Todos los derechos reservados
        </div>

    </div>

</div>

<!-- CONTENIDO -->

<div class="col-md-10">

    <!-- TOPBAR -->

    <div class="topbar">

        <div>
            <h4>¡Hola, <span class="nombre-user"><?php echo $_SESSION["nombre"]; ?></span>! 👋</h4>
            <p>Bienvenido al Sistema Biométrico de Asistencia</p>
        </div>

        <div class="topbar-right">

            <div class="notif-bell">
                <i class="fas fa-bell"></i>
                <span class="badge-count">3</span>
            </div>

            <div class="user-mini">
                <div class="avatar-circle"><i class="fas fa-user"></i></div>
                <div class="info">
                    <p><?php echo $_SESSION["nombre"]; ?></p>
                    <span>Administrador</span>
                </div>
            </div>

        </div>

    </div>

    <div class="content-area">

        <div class="fecha-box">
            <i class="fas fa-calendar"></i>
            <strong><?php echo date("d \\d\\e F \\d\\e Y"); ?></strong>
            <?php
                $dias = ["Sunday"=>"Domingo","Monday"=>"Lunes","Tuesday"=>"Martes","Wednesday"=>"Miércoles","Thursday"=>"Jueves","Friday"=>"Viernes","Saturday"=>"Sábado"];
                echo $dias[date("l")];
            ?>
        </div>

        <!-- TARJETAS RESUMEN -->

        <div class="row g-3 mb-3">

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="icon-circle"><i class="fas fa-users"></i></div>
                    <div>
                        <div class="stat-label">Aprendices</div>
                        <h2><?php echo $total["total"] ?? 0; ?></h2>
                        <div class="stat-sub">Total registrados</div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="icon-circle"><i class="fas fa-check-circle"></i></div>
                    <div>
                        <div class="stat-label">Presentes hoy</div>
                        <h2><?php echo $presentes["total"] ?? 0; ?></h2>
                        <div class="stat-sub positivo">75% del total</div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="icon-circle warning"><i class="fas fa-clock"></i></div>
                    <div>
                        <div class="stat-label">Tardanzas hoy</div>
                        <h2><?php echo $tardes["total"] ?? 0; ?></h2>
                        <div class="stat-sub alerta">5% del total</div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="icon-circle danger"><i class="fas fa-times-circle"></i></div>
                    <div>
                        <div class="stat-label">Ausentes hoy</div>
                        <h2><?php echo $ausentes["total"] ?? 0; ?></h2>
                        <div class="stat-sub negativo">20% del total</div>
                    </div>
                </div>
            </div>

        </div>

        <!-- GRAFICO + ACTIVIDAD -->

        <div class="row g-3 mb-3">

            <div class="col-md-7">
                <div class="panel-card">

                    <div class="panel-title">
                        <h6><i class="fas fa-chart-line"></i>Asistencia últimos 7 días</h6>
                        <select>
                            <option>Últimos 7 días</option>
                            <option>Últimos 30 días</option>
                        </select>
                    </div>

                    <canvas id="graficoAsistencia" height="190"></canvas>

                </div>
            </div>

            <div class="col-md-5">
                <div class="panel-card">

                    <div class="panel-title">
                        <h6><i class="fas fa-heartbeat"></i>Actividad en tiempo real</h6>
                    </div>

                    <?php
                        $actividad = [
                            ["María Fernanda López", "08:15 AM"],
                            ["Carlos Andrés Martínez", "08:14 AM"],
                            ["Laura Sofía Ruiz", "08:13 AM"],
                            ["Juan Pablo Gómez", "08:12 AM"],
                        ];
                    ?>

                    <?php foreach($actividad as $a): ?>
                    <div class="actividad-item">
                        <div class="avatar-circle"><i class="fas fa-user"></i></div>
                        <div class="info">
                            <p><?php echo $a[0]; ?></p>
                            <span>Entrada registrada</span>
                        </div>
                        <div class="hora"><?php echo $a[1]; ?></div>
                        <div class="check-ok"><i class="fas fa-check"></i></div>
                    </div>
                    <?php endforeach; ?>

                    <a href="historial.php" class="ver-todas">
                        Ver todas las actividades
                        <i class="fas fa-arrow-right"></i>
                    </a>

                </div>
            </div>

        </div>

        <!-- ACCESOS RAPIDOS + ESTADO -->

        <div class="row g-3">

            <div class="col-md-7">
                <div class="panel-card">

                    <div class="panel-title">
                        <h6><i class="fas fa-bolt"></i>Accesos rápidos</h6>
                    </div>

                    <div class="row g-2">

                        <div class="col-3">
                            <a href="asistencia.php" class="acceso-btn">
                                <i class="fas fa-fingerprint"></i>
                                Registrar asistencia
                            </a>
                        </div>

                        <div class="col-3">
                            <a href="aprendices.php" class="acceso-btn">
                                <i class="fas fa-user-graduate"></i>
                                Ver aprendices
                            </a>
                        </div>

                        <div class="col-3">
                            <a href="reportes.php" class="acceso-btn">
                                <i class="fas fa-file-alt"></i>
                                Generar reporte
                            </a>
                        </div>

                        <div class="col-3">
                            <a href="historial.php" class="acceso-btn">
                                <i class="fas fa-history"></i>
                                Ver historial
                            </a>
                        </div>

                    </div>

                </div>
            </div>

            <div class="col-md-5">
                <div class="row g-3">

                    <div class="col-8">
                        <div class="panel-card">

                            <div class="panel-title">
                                <h6><i class="fas fa-shield-alt"></i>Estado del sistema</h6>
                            </div>

                            <div class="estado-item">
                                <div class="label"><i class="fas fa-database"></i>Base de datos</div>
                                <div class="estado-valor"><span class="estado-dot"></span>Conectada</div>
                            </div>

                            <div class="estado-item">
                                <div class="label"><i class="fas fa-fingerprint"></i>Dispositivo biométrico</div>
                                <div class="estado-valor"><span class="estado-dot"></span>Conectado</div>
                            </div>

                            <div class="estado-item">
                                <div class="label"><i class="fas fa-hdd"></i>Almacenamiento</div>
                                <div class="estado-valor">
                                    <span class="barra-progreso"><span class="barra-progreso-fill" style="width:68%"></span></span>
                                    68%
                                </div>
                            </div>

                            <div class="estado-item">
                                <div class="label"><i class="fas fa-circle-notch"></i>Sistema</div>
                                <div class="estado-valor"><span class="estado-dot"></span>Activo</div>
                            </div>

                        </div>
                    </div>

                    <div class="col-4">
                        <div class="estado-ok-box">
                            <i class="fas fa-shield-check"></i>
                            <strong>Todo en orden</strong>
                        </div>
                    </div>

                </div>
            </div>

        </div>

    </div>

</div>

</div>

</div>

<script>

const ctx = document.getElementById('graficoAsistencia');

new Chart(ctx, {

type: 'bar',

data: {

labels: [
    'Lun','Mar','Mié','Jue','Vie','Sáb','Dom'
],

datasets: [{
    label: 'Asistencias',
    data: [120, 180, 150, 220, 190, 90, 70],
    backgroundColor: '#7bc46a',
    borderRadius: 4,
    borderWidth: 0
}]

},

options: {

responsive: true,

plugins: {
    legend: {
        position: 'bottom',
        labels: { boxWidth: 12, color: '#777' }
    }
},

scales: {
    y: {
        beginAtZero: true,
        grid: { color: '#f0f0f0' }
    },
    x: {
        grid: { display: false }
    }
}

}

});

</script>

<script>

async function actualizarDashboard(){

    try{

        const respuesta = await fetch("../api/dashboard.php");
        const datos = await respuesta.json();

        // Tarjetas
        document.getElementById("totalAprendices").innerHTML = datos.aprendices;
        document.getElementById("totalPresentes").innerHTML = datos.presentes;
        document.getElementById("totalTardes").innerHTML = datos.tardes;
        document.getElementById("totalAusentes").innerHTML = datos.ausentes;

        // Fecha
        document.getElementById("fechaActual").innerHTML = datos.fecha;

        // Hora
        document.getElementById("horaActual").innerHTML = datos.hora;

        // Última actividad
        let html="";

        datos.actividad.forEach(function(a){

            html+=`
            <tr>

                <td>${a.nombres} ${a.apellidos}</td>

                <td>${a.estado}</td>

                <td>${a.hora}</td>

                <td>${a.fecha}</td>

            </tr>
            `;

        });

        document.getElementById("tablaActividad").innerHTML=html;

    }catch(e){

        console.log(e);

    }

}

actualizarDashboard();

setInterval(actualizarDashboard,5000);

</script>

</body>
</html>