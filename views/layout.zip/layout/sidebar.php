
<div class="col-md-2 sidebar">

    <div>

        <div class="sidebar-brand">
            <div class="icon-box"><i class="fas fa-seedling"></i></div>
            <div>
                <h5>BioAsist SENA</h5>
                <small>Sistema Biométrico de Asistencia</small>
            </div>
        </div>

        <div class="sidebar-nav">

            <a href="dashboard.php" class="active">
                <i class="fas fa-home"></i>
                Inicio
            </a>

            <a href="aprendices.php">
                <i class="fas fa-user-graduate"></i>
                Aprendices
            </a>

            <a href="asistencia.php">
                <i class="fas fa-fingerprint"></i>
                Asistencia
            </a>

            <a href="programas.php">
                <i class="fas fa-book"></i>
                Programas
            </a>

            <a href="reportes.php">
                <i class="fas fa-file-pdf"></i>
                Reportes
            </a>

            <a href="historial.php">
                <i class="fas fa-clock"></i>
                Historial
            </a>

            <a href="dispositivos.php">
                <i class="fas fa-microchip"></i>
                Dispositivos
            </a>

            <a href="configuracion.php">
                <i class="fas fa-cog"></i>
                Configuración
            </a>

        </div>

    </div>

    <div class="sidebar-bottom">

        <div class="sidebar-biometric">
            <div class="icon-box"><i class="fas fa-fingerprint"></i></div>
            <div>
                <strong>Sistema biométrico</strong>
                <span><i class="fas fa-circle"></i>Conectado</span>
            </div>
        </div>

        <div class="sidebar-footer">
            © <?php echo date("Y"); ?> SENA<br>
            Todos los derechos reservados
        </div>

    </div>

</div>